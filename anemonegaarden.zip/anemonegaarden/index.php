<?php
 define( 'WP_USE_THEMES', true ); require __DIR__ . '/wp-blog-header.php'; 